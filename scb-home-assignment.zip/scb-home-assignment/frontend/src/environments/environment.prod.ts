export const environment = {
  production: true,
  server: 'http://localhost:8080/Gradle___com_sc_interview___crud_app_0_0_1_war'
};
