# Initialize terraform
terraform init

# Create workspace in terraform
terraform workspace new DEV

# check created workspace
terraform workspace list
