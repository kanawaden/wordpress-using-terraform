Things Completed
- Jenkins to build UI and Backend
- Terraform scripts to bring up infra

Things to improve
- Packr script to bake an AMI (frontend and backend)
- Jenkinsfile can be extended to add SonarQube, OWASP Dependency Check and execute Autoamted tests.
- Application can be dockerized and deployed into kubernetes.

##############################################################

Screenshots

Add User
![Alt text](screenshots/add-users.png?raw=true "Title")

List Users
![Alt text](screenshots/list-users.png?raw=true "Title") 

Delete User
![Alt text](screenshots/delete-users.png?raw=true "Title")
