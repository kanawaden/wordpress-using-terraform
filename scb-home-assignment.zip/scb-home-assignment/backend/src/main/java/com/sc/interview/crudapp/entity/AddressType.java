package com.sc.interview.crudapp.entity;

public enum AddressType {
    Residence,
    Office
}
