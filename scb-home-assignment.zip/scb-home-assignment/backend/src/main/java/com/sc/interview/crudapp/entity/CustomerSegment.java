package com.sc.interview.crudapp.entity;

public enum CustomerSegment {
    Retail
}
