package com.sc.interview.crudapp.entity;

public enum Gender {
    M,
    F,
    O
}
