package com.sc.interview.crudapp.constant;

public class SchemaConstant {
    public static final String SchemaName = "SC_CRUD";
}
